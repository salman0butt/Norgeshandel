<?php

namespace App\Http\Controllers\Admin\Job;

use App\Http\Controllers\Controller;
use App\Admin\Jobs\JobMeta;
use Illuminate\Http\Request;

class JobMetaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Admin\Jobs\JobMeta  $jobMeta
     * @return \Illuminate\Http\Response
     */
    public function show(JobMeta $jobMeta)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Admin\Jobs\JobMeta  $jobMeta
     * @return \Illuminate\Http\Response
     */
    public function edit(JobMeta $jobMeta)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Admin\Jobs\JobMeta  $jobMeta
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, JobMeta $jobMeta)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Admin\Jobs\JobMeta  $jobMeta
     * @return \Illuminate\Http\Response
     */
    public function destroy(JobMeta $jobMeta)
    {
        //
    }
}
