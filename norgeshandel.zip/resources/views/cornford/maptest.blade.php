<div style="width: 500px; height: 500px;">
	{!! Mapper::render() !!}
</div>