<div class="row product-list-item mr-1 p-sm-1 mt-3">
    <div class="image-section col-sm-4 p-2">
        <img src="{{url('public/images/image-placeholder.jpg')}}" alt="" class="img-fluid radius-8">
    </div>
    <div class="detailed-section col-sm-8 p-2">
        <div style="width:100%;">
            <div class="week-status u-t5 text-muted" style="">Ukens bolig</div>
            <a class="float-right" style="cursor: pointer;"><span class="fa fa-trash-alt text-muted"></span></a>
            <div class="location u-t5 text-muted mt-2">Agnesodden 12B, Stavern</div>
            <p class="detail u-t5 mt-3 text-muted">Eier (Selveier) • Tomannsbolig • 3 soverom <br>DNB Eiendom AS</p>
        </div>
        <a href="#" class="dme-btn-outlined-blue float-right">Flere valg</a>
        <a href="#" class="dme-btn-outlined-blue float-right mr-2">Fullfør annonsen</a>
    </div>
</div>
