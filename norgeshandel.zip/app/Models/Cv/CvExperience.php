<?php

namespace App\Models\Cv;

use Illuminate\Database\Eloquent\Model;

class CvExperience extends Model
{
    protected $guarded = [];
}
