<?php

namespace App\Models\Cv;

use Illuminate\Database\Eloquent\Model;

class CvPreference extends Model
{
    protected $guarded = [];
}
