<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RealestateBusinessPlot extends Model
{
    //
    protected $table = 'realestate_business_plots';
    protected $guarded = [];
}
