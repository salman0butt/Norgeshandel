<?php

namespace App\Admin\Jobs;

use Illuminate\Database\Eloquent\Model;

class JobMeta extends Model
{
    //
}
